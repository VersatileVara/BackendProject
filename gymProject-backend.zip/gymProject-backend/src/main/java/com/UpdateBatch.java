package com;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet(urlPatterns = { "/UpdateBatch"})
public class UpdateBatch extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int batch_id = Integer.parseInt(request.getParameter("batch_id"));
        String name = request.getParameter("name");

        try (Connection connection = DB.getConnection()) {
        	 if (isBatchNameExists(connection, name)) {
                 request.setAttribute("name", name);
                 request.getRequestDispatcher("nameExists.jsp").forward(request, response);
                 return;
        	 }
            PreparedStatement ps = connection.prepareStatement("UPDATE batch SET name = ? WHERE batch_id = ?");
            ps.setString(1, name);
            ps.setInt(2, batch_id);
            ps.executeUpdate();

            connection.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        response.sendRedirect("index.html");
    
    }
    private boolean isBatchNameExists(Connection connection, String name) throws SQLException {
        String query = "SELECT COUNT(*) FROM batch WHERE name = ?";
        try (PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setString(1, name);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next() && rs.getInt(1) > 0) {
                    return true;
                }
            }
        }
        return false;
    }
   
}
