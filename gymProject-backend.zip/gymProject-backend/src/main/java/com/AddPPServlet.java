package com;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/AddPPServlet")
public class AddPPServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        out.println("<html><body>");
        out.println("<h2>Add PP</h2><br>");
        out.println("<form action='AddPPServlet' method='POST'><br>");
        out.println("Name: <input type='text' name='name'><br><br>");
        out.println("Email: <input type='text' name='email'><br><br>");
        out.println("Phone: <input type='text' name='phone'><br><br>");
        out.println("Batch: <select name='batch_id'>");

        try (Connection connection = DB.getConnection()) {
            PreparedStatement ps = connection.prepareStatement("SELECT batch_id, name FROM batch");
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                out.println("<option value='" + rs.getInt("batch_id") + "'>" + rs.getString("name") + "</option>");
            }

            connection.close();
        } catch (Exception e) {
            e.printStackTrace();
            out.println("Error: " + e.getMessage());
        }

        out.println("</select><br><br>");
        out.println("<input type='submit' value='Add PP'>");
        out.println("</form>");
        out.println("</body></html>");
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String phone = request.getParameter("phone");
        int batch_id = Integer.parseInt(request.getParameter("batch_id"));

        try (Connection connection = DB.getConnection()) {
            PreparedStatement ps = connection.prepareStatement("INSERT INTO pp (name, email, phone, batch_id) VALUES (?, ?, ?, ?)");
            ps.setString(1, name);
            ps.setString(2, email);
            ps.setString(3, phone);
            ps.setInt(4, batch_id);
            ps.executeUpdate();

            connection.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        response.sendRedirect("index.html");
    }
}
