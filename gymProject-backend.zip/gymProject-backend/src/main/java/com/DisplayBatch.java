package com;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/DisplayBatch")
public class DisplayBatch extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        List<Batch> batches = new ArrayList<>();

        try (Connection connection = DB.getConnection()) {
            String query = "SELECT * FROM batch";
            try (PreparedStatement ps = connection.prepareStatement(query);
                 ResultSet rs = ps.executeQuery()) {

                while (rs.next()) {
                    Batch batch = new Batch();
                    batch.setId(rs.getInt("batch_id"));
                    batch.setName(rs.getString("name"));
                    batches.add(batch);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        out.println("<html>");
        out.println("<head>");
        out.println("<title>Batches</title>");
        out.println("</head>");
        out.println("<body>");
        out.println("<style>");
        out.println("th, td {border: 1px solid black; padding: 10px 20px; margin: 5px; }");
        out.println("</style>");
        out.println("<center>");
        out.println("<h1>Batches</h1>");
        out.println("<table border='1'>");
        out.println("<tr><th colspan= '10'>ID</th><th>Name</th></tr>");

        for (Batch batch : batches) {
            out.println("<tr>");
            out.println("<td colspan= '10'><br>" + batch.getId() + "<br></td>");
            out.println("<td colspan= '10'><br>" + batch.getName() + "<br></td>");
            out.println("</tr>");
        }

        out.println("</table>");
        out.println("</center>");
        out.println("</body>");
        out.println("</html>");

        out.close();
    }
}
