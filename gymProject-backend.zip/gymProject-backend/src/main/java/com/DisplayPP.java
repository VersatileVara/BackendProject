package com;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/DisplayPP")
public class DisplayPP extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        List<PP> participants = new ArrayList<>();

        try (Connection connection = DB.getConnection()) {
            String query = "SELECT * FROM pp";
            try (PreparedStatement ps = connection.prepareStatement(query);
                 ResultSet rs = ps.executeQuery()) {

                while (rs.next()) {
                    PP participant = new PP();
                    participant.setId(rs.getInt("pp_id"));
                    participant.setName(rs.getString("name"));
                    participant.setEmail(rs.getString("email"));
                    participant.setPhone(rs.getString("phone"));
                    participant.setBatchId(rs.getInt("batch_id"));
                    participants.add(participant);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        out.println("<html>");
        out.println("<head>");
        out.println("<title>Participants</title>");
        out.println("</head>");
        out.println("<body>");
        out.println("<h1>Participants</h1>");
        out.println("<table border='1'>");
        out.println("<tr><th>ID</th><th>Name</th><th>Phone</th><th>Email</th><th>Batch ID</th></tr>");

        for (PP participant : participants) {
            out.println("<tr>");
            out.println("<td>" + participant.getId() + "</td>");
            out.println("<td>" + participant.getName() + "</td>");
            out.println("<td>" + participant.getPhone() + "</td>");
            out.println("<td>" + participant.getEmail() + "</td>");
            out.println("<td>" + participant.getBatchId() + "</td>");
            out.println("</tr>");
        }

        out.println("</table>");
        out.println("</body>");
        out.println("</html>");

        out.close();
    }
}

