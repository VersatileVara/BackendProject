package com;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet(urlPatterns = { "/AddBatch"})
public class AddBatch extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String name = request.getParameter("name");

        try (Connection connection = DB.getConnection()) {
            PreparedStatement ps = connection.prepareStatement("INSERT INTO batch (name) VALUES (?)");
            ps.setString(1, name);
            ps.executeUpdate();
            
            int batchId = getGeneratedBatchId(connection);

         // Now you can construct a response or perform further operations with batchId
         String message = "New Batch added!<br>"
                 + "Batch Name: " + name + "<br>"
                 + "Batch ID: " + batchId;

         // Set message attribute and forward to thankYou.jsp
         request.setAttribute("message", message);
         request.getRequestDispatcher("thankYou.jsp").forward(request, response);
            connection.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        response.sendRedirect("index.html");
    }
    
    private int getGeneratedBatchId(Connection connection) throws SQLException {
        try (PreparedStatement ps = connection.prepareStatement("SELECT LAST_INSERT_ID()")) {
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1);
                }
            }
        }
        throw new SQLException("Failed to retrieve generated batch ID.");
    }
}

