package com;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/UpdatePPServlet")
public class UpdatePPServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        out.println("<html><body>");
        out.println("<h2>Update PP</h2>");
        out.println("<form action='UpdatePPServlet' method='POST'>");
        out.println("Email: <input type='text' name='email'><br>");
        out.println("New Name: <input type='text' name='name'><br>");
        out.println("New Phone: <input type='text' name='phone'><br>");
        out.println("New Batch: <select name='batch_id'>");

        try (Connection connection = DB.getConnection()) {
            PreparedStatement ps = connection.prepareStatement("SELECT batch_id, name FROM batch");
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                out.println("<option value='" + rs.getInt("batch_id") + "'>" + rs.getString("name") + "</option>");
            }
            connection.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

        out.println("</select><br>");
        out.println("<input type='submit' value='Update PP'>");
        out.println("</form>");
        out.println("</body></html>");
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String email = request.getParameter("email");
        String name = request.getParameter("name");
        String phone = request.getParameter("phone");
        int batch_id = Integer.parseInt(request.getParameter("batch_id"));

        try (Connection connection = DB.getConnection()) {
            PreparedStatement ps = connection.prepareStatement("UPDATE pp SET name = ?, phone = ?, batch_id = ? WHERE email = ?");
            ps.setString(1, name);
            ps.setString(2, phone);
            ps.setInt(3, batch_id);
            ps.setString(4, email);
            int rowsAffected = ps.executeUpdate();            

            if (rowsAffected > 0) {
                response.sendRedirect("success.jsp");
            } else {
                response.sendRedirect("error.jsp");
            }
            connection.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
      //  response.sendRedirect("index.html");
    }
}
